package sample;

import javax.swing.*;


public class ConfigPanel extends JPanel {
    final MainFrame frame;
    JLabel label;         //drawing regular polygons
    JSpinner sidesField;  //number of slides
    JComboBox colorCombo; //the color of the shape
    JLabel sidesLabel;

    public ConfigPanel(MainFrame frame) {
        this.frame = frame;
        init();
    }

    private void init() {
        //the label and the spinner
        sidesLabel = new JLabel("Number of slides:");
        sidesField = new JSpinner(new SpinnerNumberModel(0, 0, 100,1));
        sidesField.setValue(6); //defaut number of sides

       add(sidesLabel);
       add(sidesField);
       add(colorCombo);
    }
}
