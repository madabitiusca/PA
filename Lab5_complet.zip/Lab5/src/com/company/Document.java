package com.company;

import java.io.File;
import java.io.Serializable;
import java.net.URI;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

public class Document implements Serializable {
    private String location;
    private UUID id;
    private String name;
    private Map<String,String> tags;

    public Document(String location, String name) {
        super();
        this.location = location;
        this.id = UUID.randomUUID();
        this.name=name;
        this.tags = new HashMap();
    }

    public void setTags(Map<String, String> tags) {
        this.tags = tags;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public Map <String,String> getTags() {
        return this.tags;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    public void addTag(String key, String val){
        tags.put(key,val);
    }

    public void print() {
        System.out.println("\tName: " + this.name + "\n\tTags: ");
        Iterator var = tags.entrySet().iterator();

        while(var.hasNext()) {
            Map.Entry<Object,String> entry = (Map.Entry)var.next();
            Object key = (String)entry.getKey();
            String val = (String)entry.getValue();
            System.out.println(key + ": " + val );
        }
    }

}
