package com.company;

import java.awt.*;
import java.io.*;
import java.util.ArrayList;

public class CatalogUtil {
    private Catalog catalog;

    CatalogUtil(Catalog catalog) {
        this.catalog = catalog;
    }


    public void save() throws IOException {
        String file = "catalog.ser";
        FileOutputStream fileOutputStream = new FileOutputStream(file);
        ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
        objectOutputStream.writeObject(this.catalog);
        objectOutputStream.close();
        fileOutputStream.close();


    }
    public Catalog load()
            throws IOException, ClassNotFoundException {
        new Catalog();
        FileInputStream fileInputStream = new FileInputStream("catalog.ser");
        ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
        Catalog loadCatalog = (Catalog)objectInputStream.readObject();
        objectInputStream.close();
        fileInputStream.close();
        return loadCatalog;
    }

    public void view() throws IOException {
        new ArrayList();
        ArrayList<Document> doc = this.catalog.getDocuments();
        for(int i=0; i<doc.size();i++) {
            System.out.println("DOC " + i );
            ((Document)doc.get(i)).print();
        }
        if(!Desktop.isDesktopSupported()) { System.out.println("desktop not supported");
        } else {
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            String docRead = reader.readLine();
            int index = Integer.parseInt(docRead);
            Desktop desktop = Desktop.getDesktop();
            File file = new File(((Document)doc.get(index-1)).getLocation());
            if(file.exists()) {
                desktop.open(file);
            }
        }
    }

    public void newCatalog(Catalog catalog) {
            this.catalog = catalog;
    }
}