package com.company;

import java.io.IOException;

public class Main {
    public Main(){
    }


    public static void main(String[] args) throws IOException, ClassNotFoundException {
        Document document1 = new Document("C:\\Users\\Bitiusca\\IdeaProjects\\pa\\Lab5\\src\\com\\company\\Catalog.java","Catalog" );
        Document document2 = new Document("C:\\Users\\Bitiusca\\IdeaProjects\\pa\\Lab5\\src\\com\\company\\Document.java","Document");
        Document document3 = new Document("C:\\Users\\Bitiusca\\IdeaProjects\\pa\\Lab5\\src\\com\\company\\Main.java", "Main");

        document1.addTag("title","TITLE");
        document1.addTag("year","YEAR");
        document1.addTag("type","TYPE");

        document2.addTag("title","TITLE");
        document2.addTag("year","YEAR");
        document2.addTag("type","TYPE");

        document3.addTag("title","TITLE");
        document3.addTag("year","YEAR");
        document3.addTag("type","TYPE");

        Catalog catalog = new Catalog();
        catalog.add(document1);
        catalog.add(document2);
        catalog.add(document3);
        CatalogUtil catalogUtil = new CatalogUtil(catalog);
        catalogUtil.save();
        Catalog catalogSave = catalogUtil.load();
        catalogUtil.newCatalog(catalogSave);
        catalogUtil.view();



    }
}
